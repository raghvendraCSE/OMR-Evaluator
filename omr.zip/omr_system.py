"""
OMR (Optical Mark Recognition) System
Enhanced version to handle images, PDFs, folders, and GUI file browsing.
Automatically evaluates and scores answer sheets.
"""

import cv2
import numpy as np
import json
import os
from pathlib import Path
from typing import List, Tuple, Dict
from dataclasses import dataclass
from pdf2image import convert_from_path
import matplotlib.pyplot as plt
from tkinter import Tk, filedialog

@dataclass
class OMRConfig:
    blur_kernel_size: int = 5
    threshold_block_size: int = 11
    threshold_c: int = 2
    min_bubble_area: int = 50
    max_bubble_area: int = 2000
    min_contour_area: int = 30
    min_questions: int = 10
    min_options: int = 4
    grid_tolerance: float = 0.1
    correct_mark_threshold: float = 0.3
    partial_credit: bool = False

@dataclass
class AnswerSheet:
    student_id: str
    answers: List[str]
    score: float
    total_questions: int
    correct_answers: int
    incorrect_answers: int
    blank_answers: int
    confidence_scores: List[float]
    processing_errors: List[str]

class OMRProcessor:
    def __init__(self, config: OMRConfig = None):
        self.config = config or OMRConfig()
        self.answer_key = []
        self.question_count = 0
        self.option_count = 4  # Default A-D

    def load_answer_key(self, answer_key_path: str):
        try:
            with open(answer_key_path, 'r') as f:
                data = json.load(f)
                self.answer_key = data.get('answers', [])
                self.question_count = len(self.answer_key)
                print(f"Loaded answer key with {self.question_count} questions")
        except Exception as e:
            raise ValueError(f"Error loading answer key: {e}")

    def preprocess_image(self, image_path: str) -> np.ndarray:
        image = cv2.imread(image_path)
        if image is None:
            raise ValueError(f"Could not load image: {image_path}")
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        blurred = cv2.GaussianBlur(gray, (self.config.blur_kernel_size, self.config.blur_kernel_size), 0)
        thresh = cv2.adaptiveThreshold(
            blurred, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
            cv2.THRESH_BINARY_INV, self.config.threshold_block_size, self.config.threshold_c
        )
        return thresh

    def detect_answer_grid(self, processed_image: np.ndarray) -> Tuple[List, List]:
        contours, _ = cv2.findContours(processed_image, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        valid_contours = [c for c in contours if self.config.min_contour_area < cv2.contourArea(c) < self.config.max_bubble_area]
        if len(valid_contours) < self.config.min_questions * self.config.min_options:
            raise ValueError("Insufficient contours detected. Check image quality.")
        valid_contours = sorted(valid_contours, key=lambda c: (cv2.boundingRect(c)[1], cv2.boundingRect(c)[0]))

        rows = []
        current_row = []
        last_y = -1
        for contour in valid_contours:
            x, y, w, h = cv2.boundingRect(contour)
            if last_y == -1 or abs(y - last_y) < 20:
                current_row.append((contour, x, y, w, h))
            else:
                if current_row:
                    current_row.sort(key=lambda x: x[1])
                    rows.append(current_row)
                current_row = [(contour, x, y, w, h)]
            last_y = y
        if current_row:
            current_row.sort(key=lambda x: x[1])
            rows.append(current_row)
        return rows, valid_contours

    def detect_marked_answers(self, processed_image: np.ndarray, rows: List) -> List[List[bool]]:
        answers = []
        for row in rows:
            row_answers = []
            for contour, x, y, w, h in row:
                roi = processed_image[y:y+h, x:x+w]
                fill_ratio = np.count_nonzero(roi) / (roi.shape[0] * roi.shape[1]) if roi.size > 0 else 0
                row_answers.append(fill_ratio > self.config.correct_mark_threshold)
            answers.append(row_answers)
        return answers

    def process_answer_sheet(self, image_path: str) -> AnswerSheet:
        errors = []
        try:
            processed_image = self.preprocess_image(image_path)
            rows, _ = self.detect_answer_grid(processed_image)
            marked_answers = self.detect_marked_answers(processed_image, rows)

            answers = []
            confidence_scores = []

            for row_answers in marked_answers:
                marked_count = sum(row_answers)
                if marked_count == 0:
                    answers.append('')
                    confidence_scores.append(0.0)
                elif marked_count == 1:
                    option_idx = row_answers.index(True)
                    answers.append(chr(ord('A') + option_idx))
                    confidence_scores.append(0.9)
                else:
                    answers.append('MULTIPLE')
                    confidence_scores.append(0.3)

            score, correct, incorrect, blank = self.calculate_score(answers)
            student_id = self.extract_student_id(image_path)
            return AnswerSheet(student_id, answers, score, self.question_count, correct, incorrect, blank, confidence_scores, errors)
        except Exception as e:
            errors.append(str(e))
            return AnswerSheet("UNKNOWN", [], 0.0, self.question_count, 0, 0, 0, [], errors)

    def calculate_score(self, answers: List[str]) -> Tuple[float, int, int, int]:
        if not self.answer_key:
            return 0.0, 0, 0, len(answers)
        correct = incorrect = blank = 0
        for i, answer in enumerate(answers):
            if i >= len(self.answer_key):
                break
            if answer == '':
                blank += 1
            elif answer == 'MULTIPLE':
                incorrect += 1
            elif answer.upper() == self.answer_key[i].upper():
                correct += 1
            else:
                incorrect += 1
        total_questions = len(self.answer_key)
        score = (correct / total_questions) * 100 if total_questions else 0
        return score, correct, incorrect, blank

    def extract_student_id(self, image_path: str) -> str:
        return os.path.splitext(os.path.basename(image_path))[0]

    def process_batch(self, input_path: str) -> List[AnswerSheet]:
        results = []
        supported_images = ['.jpg', '.jpeg', '.png', '.bmp', '.tiff', '.tif']
        input_path = Path(input_path)

        files_to_process = []
        if input_path.is_file():
            files_to_process.append(input_path)
        elif input_path.is_dir():
            for f in input_path.iterdir():
                files_to_process.append(f)

        for file in files_to_process:
            if file.suffix.lower() in supported_images:
                print(f"Processing image: {file.name}")
                results.append(self.process_answer_sheet(str(file)))
            elif file.suffix.lower() == '.pdf':
                print(f"Processing PDF: {file.name}")
                pages = convert_from_path(str(file))
                for idx, page in enumerate(pages):
                    temp_path = f"{file.stem}_page{idx+1}.png"
                    page.save(temp_path, 'PNG')
                    results.append(self.process_answer_sheet(temp_path))
                    os.remove(temp_path)
            else:
                print(f"Skipped unsupported file: {file.name}")
        return results

    def generate_report(self, results: List[AnswerSheet], output_path: str = None) -> Dict:
        if not results:
            return {"error": "No results to report"}
        total_sheets = len(results)
        avg_score = np.mean([r.score for r in results])
        avg_confidence = np.mean([np.mean(r.confidence_scores) for r in results if r.confidence_scores])
        error_count = sum(len(r.processing_errors) for r in results)
        score_ranges = {
            "90-100": sum(1 for r in results if 90 <= r.score <= 100),
            "80-89": sum(1 for r in results if 80 <= r.score < 90),
            "70-79": sum(1 for r in results if 70 <= r.score < 80),
            "60-69": sum(1 for r in results if 60 <= r.score < 70),
            "0-59": sum(1 for r in results if 0 <= r.score < 60)
        }
        report = {
            "summary": {
                "total_sheets_processed": total_sheets,
                "average_score": round(avg_score, 2),
                "average_confidence": round(avg_confidence, 3),
                "processing_errors": error_count,
                "success_rate": round((total_sheets - error_count) / total_sheets * 100, 2)
            },
            "score_distribution": score_ranges,
            "detailed_results": [
                {
                    "student_id": r.student_id,
                    "score": round(r.score, 2),
                    "correct_answers": r.correct_answers,
                    "incorrect_answers": r.incorrect_answers,
                    "blank_answers": r.blank_answers,
                    "confidence": round(np.mean(r.confidence_scores), 3) if r.confidence_scores else 0,
                    "errors": r.processing_errors
                } for r in results
            ]
        }
        if output_path:
            with open(output_path, 'w') as f:
                json.dump(report, f, indent=2)
            print(f"Report saved to: {output_path}")
        return report

    def visualize_results(self, results: List[AnswerSheet], output_dir: str = "omr_results"):
        os.makedirs(output_dir, exist_ok=True)
        scores = [r.score for r in results]
        plt.figure(figsize=(10, 6))
        plt.hist(scores, bins=20, alpha=0.7, color='skyblue', edgecolor='black')
        plt.xlabel('Score')
        plt.ylabel('Number of Students')
        plt.title('Score Distribution')
        plt.grid(True, alpha=0.3)
        plt.savefig(os.path.join(output_dir, 'score_distribution.png'))
        plt.close()

        all_confidences = [c for r in results for c in r.confidence_scores]
        if all_confidences:
            plt.figure(figsize=(10, 6))
            plt.hist(all_confidences, bins=20, alpha=0.7, color='lightgreen', edgecolor='black')
            plt.xlabel('Confidence Score')
            plt.ylabel('Frequency')
            plt.title('Mark Detection Confidence Distribution')
            plt.grid(True, alpha=0.3)
            plt.savefig(os.path.join(output_dir, 'confidence_distribution.png'))
            plt.close()
        print(f"Visualizations saved to: {output_dir}")


def main():
    import argparse
    parser = argparse.ArgumentParser(description='OMR System for Answer Sheet Processing')
    parser.add_argument('--input', '-i', help='Input image, PDF, or directory path')
    parser.add_argument('--answer-key', '-k', help='Path to answer key JSON file')
    parser.add_argument('--output', '-o', help='Output directory for results')
    parser.add_argument('--config', '-c', help='Path to configuration JSON file')
    parser.add_argument('--gui', action='store_true', help='Use GUI to select files/folders')
    args = parser.parse_args()

    config = OMRConfig()
    if args.config and os.path.exists(args.config):
        with open(args.config, 'r') as f:
            data = json.load(f)
            for key, value in data.items():
                if hasattr(config, key):
                    setattr(config, key, value)

    if args.gui:
        root = Tk()
        root.withdraw()
        if not args.input:
            args.input = filedialog.askopenfilename(title="Select Image, PDF, or Folder") or filedialog.askdirectory(title="Select Folder")
        if not args.answer_key:
            args.answer_key = filedialog.askopenfilename(title="Select Answer Key JSON")
        if not args.output:
            args.output = filedialog.askdirectory(title="Select Output Folder")
        root.destroy()

    if not args.input or not args.answer_key:
        print("Input path and answer key are required.")
        return

    omr = OMRProcessor(config)
    omr.load_answer_key(args.answer_key)

    results = omr.process_batch(args.input)

    output_dir = args.output or "omr_results"
    os.makedirs(output_dir, exist_ok=True)

    report = omr.generate_report(results, os.path.join(output_dir, 'report.json'))
    omr.visualize_results(results, output_dir)

    print("\n" + "="*50)
    print("OMR PROCESSING COMPLETE")
    print("="*50)
    print(f"Total sheets processed: {report['summary']['total_sheets_processed']}")
    print(f"Average score: {report['summary']['average_score']}%")
    print(f"Success rate: {report['summary']['success_rate']}%")
    print(f"Results saved to: {output_dir}")
    print("="*50)

if __name__ == "__main__":
    main()
